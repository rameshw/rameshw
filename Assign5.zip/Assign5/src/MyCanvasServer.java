import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * Canvas for server
 * @author rameshweerakoon
 *
 */
public class MyCanvasServer extends JPanel{
	Image img;
	public MyCanvasServer(Image img){
		this.img=img;
	}
	
	public void init(){
		
	}
	
	public void paintComponent(Graphics g){
		g.drawImage(img, 0, 0, 400, 400, this);
	}
	
	public void setImage(Image img){
		this.img=img;
		repaint();
	}
	
	
}
