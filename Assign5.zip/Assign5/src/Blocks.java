import java.awt.image.BufferedImage;
import java.io.Serializable;

/**
 * Stores Coordinates of a block and pixel values
 * @author rameshweerakoon
 *
 */
public class Blocks implements Serializable{
	private int x;
	private int y;
	private  boolean isSet;
	int[] pixel;
	String BlockStamp="";
	
	/**
	 * set initial locations
	 * @param x, set x Coordinate
	 * @param y, set y Coordinate
	 */
	public Blocks(int x,int y ){
		this.x=x;
		this.y=y;	
		this.pixel=new int[20*20];
		this.isSet=false;
		this.BlockStamp="";
		//this.subImage=new BufferedImage(400, 400, BufferedImage.TYPE_INT_RGB);
	}
	
	/**
	 * return the x coordinate
	 * @return x coordinate
	 */
	public int getX(){
		return this.x;
	}
	
	/**
	 * return the y coordinate
	 * @return y coordinate
	 */
	public int getY(){
		return this.y;
	}
	
	/**
	 * setBlock pixels and stamp
	 * @param pixel, pixel array
	 * @param s, timestamp
	 */
	public synchronized void setBlock(int[] pixel,String s){
		this.isSet=true;
		this.pixel=pixel;
		this.BlockStamp=s;
	}
	
	/**
	 * check is slready set
	 * @return true if set
	 */
	public synchronized boolean isSet(){
		return this.isSet;
	}
	
	/**
	 * return pixel array
	 * @return pixel
	 */
	public int[] getImg(){
		return pixel;
	}
	
	/**
	 * set status of block
	 * @param b, new status
	 * @param s, timestamp
	 */
	public synchronized void setStatus(Boolean b, String s, int p[]){
		this.isSet=b;
		this.BlockStamp=s;
		this.pixel=p;
	}
	
	/**
	 * return timestamp
	 * @return, timestamp
	 */
	public String getStamp(){
		return this.BlockStamp;
	}
}
