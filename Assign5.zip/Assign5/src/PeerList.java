import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * List of peers
 * @author rameshweerakoon
 *
 */
public class PeerList implements Serializable{
	ArrayList<Peers> peers;
	int count;
	public PeerList(){
		peers=new ArrayList<Peers>();
		count=0;
	}
	
	/**
	 * add new peers
	 * @param address, address of peer
	 * @param port, port of peer
	 */
	public synchronized void addPeer(String address, int port){
		this.count++;
		Peers a=new Peers(address, port);
		a.setID(this.count);
		peers.add(a);
	}
	
	/**
	 * remove a peer, 
	 * @param address of peer
	 * @param port of peer
	 */
	public synchronized void removePeer(String address, int port){	
		Iterator<Peers> it=peers.iterator();
		while(it.hasNext()){
			Peers p=it.next();
			if(p.getAdd().equals(address) && p.getPort()==port){
				peers.remove(p);
			}
		}
	}
	
	/**
	 * return size of peer
	 * @return
	 */
	public int getSize(){
		return peers.size();
	}
	
	/**
	 * return a peer from list
	 * @param i, index in list
	 * @return peer
	 */
	public Peers getPeer(int i){
		return this.peers.get(i);
	}
	
}
