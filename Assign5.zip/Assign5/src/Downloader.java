import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

/**
 * A downloader for each connection for peer to uploader
 * @author rameshweerakoon
 *
 */
public class Downloader extends Thread{

	PeerList list;
	ImageBlocks blocks;
	MyCanvasPeer canvas;
	//UploadServer myUPServer;
	String myUpAddress;
	int myUpPort;	
	String serverUploaderAdd;
	int serverUploaderPort;
	ObjectInputStream reader;
	ObjectOutputStream writer;
	Blocks newBlock;
	String Blockstamp;
	
	public Downloader(PeerList list, String serverAdd, int serverUploader, String a, int b, ImageBlocks bl, MyCanvasPeer c){		
		this.list=list;
		this.canvas=c;
		this.myUpAddress=a;
		this.myUpPort=b;
		this.blocks=bl;
		this.serverUploaderPort=serverUploader;
		this.serverUploaderAdd=serverAdd;
		this.Blockstamp="";
	}
	
	/**
	 * run for thread
	 */
	public void run(){
		//search for missing blocks
		ArrayList<Blocks> request;

		//make request + get peer list - (connecting to server uploader)
		PeerList newlist=null;
		Socket sock=null;
		try {
			sock = new Socket(this.serverUploaderAdd, this.serverUploaderPort);
			System.out.println("Server upload port: " +this.serverUploaderAdd+" " + this.serverUploaderPort);
						 
			 writer=new ObjectOutputStream(sock.getOutputStream());
			 reader=new ObjectInputStream(sock.getInputStream());
			 
			 System.out.println("Yoo" );
		System.out.println("Size: "  + blocks.getRequiredBlock().size());
		while (blocks.getRequiredBlock().size()>0){
			System.out.print(blocks.getRequiredBlock().size());
				//looking for empty blocks
				request=blocks.getRequiredBlock();
				Request req=new Request(request);

				writer.reset();
				writer.writeObject(req);
				writer.flush();
				
				//reader.;
				newBlock=(Blocks) reader.readObject();
				//System.out.println(newBlock.getX()+","+newBlock.getY() + " recieved");
				newlist=(PeerList) reader.readObject();
			
				
		///process response///		
		
			//process peer list to remove upload server of this peer
		
			//update peer list
				PeerList newPeers = new PeerList();
			for (Peers newp: newlist.peers){
				for (int i=0; i<list.getSize();i++){
					Peers old=list.getPeer(i);
					if (newp.getPort()==old.getPort()){ 
						break;
					}
					
					if (i==list.getSize()-1){
						System.out.println("New found peer:" +newp.getAdd()+ " " + newp.getPort());	
						newPeers.addPeer(newp.getAdd(), newp.getPort());												
					}
				}
			}
			if (newBlock.getX()==0 && newBlock.getY()==0){	
				if(this.Blockstamp.equals("") ){
					this.Blockstamp=newBlock.getStamp();
				}
				System.out.print("first");
				System.out.println(newBlock.getStamp());
			}
			
			//set new block and redraw GUI
			if (newBlock!=null && !blocks.getBlock(newBlock.getX(), newBlock.getY()).isSet()){
				//change timestamp
				if(!newBlock.getStamp().equals(this.Blockstamp)){
					System.out.print(newBlock.getStamp()+ " REseet");
					//blocks=new ImageBlocks();					
					this.Blockstamp=newBlock.getStamp();
					//resetALL(this.Blockstamp);
					//this.canvas.newImage(blocks);
				}else{
					System.out.println(newBlock.getStamp());
					blocks.setBlock(newBlock, this.Blockstamp);
					this.canvas.paintImmediately(0, 0, 400, 400);		
				}								
			}
			
			//new peers
			for (Peers newAdd: newPeers.peers){
				list.addPeer(newAdd.getAdd(), newAdd.getPort());

				//start other downloaders for new peers
				Downloader download=new Downloader(list, this.myUpAddress, this.myUpPort, newAdd.getAdd(), newAdd.getPort(), blocks, this.canvas);
				download.start();			
			}			
		}
		reader.close();writer.close();

		sock.close();	
	} catch (UnknownHostException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	}
	
	
	private  void resetALL(String s){
		System.out.println("Resetting");
		int[] pixel=new int[20*20];
		for (int x=0;x<20;x++){
			for (int y=0;y<20;y++){
				blocks.getBlock(x, y).setStatus(false, s, pixel);
				//Blocks a =new Blocks(x,y);
				//blocks.ResetBlock(a, s);			
			}
		}
	}
	
}
