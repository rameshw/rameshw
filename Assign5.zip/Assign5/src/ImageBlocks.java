
import java.io.Serializable;
import java.util.ArrayList;

/**
 * Class manages all blocks of a Image
 * @author rameshweerakoon
 *
 */
public class ImageBlocks implements Serializable{
	Blocks[][] subImage;
	String BlockStamp="";
	
	public ImageBlocks(){
		//this.BlockStamp=s;
		this.subImage= new Blocks[20][20];	
		for (int x=0;x<20;x++){
			for (int y=0;y<20;y++){
				subImage[x][y]=new Blocks(x,y);
			}
		}
	}
	
	/**
	 * function sets block
	 * @param block, new block
	 * @param s, time stamp
	 */
	public  synchronized void setBlock(Blocks block, String s){
		this.subImage[block.getX()][block.getY()].setBlock(block.getImg(),s);
	}
	
	/**
	 * return a specific block
	 * @param x, x value
	 * @param y, y value
	 * @return Block
	 */
	public synchronized Blocks getBlock(int x, int y){	
		return subImage[x][y];
	}
	
	/**
	 * create list of all empty blocks
	 * @return
	 */
	public synchronized ArrayList<Blocks> getRequiredBlock(){
		ArrayList<Blocks> empty = new ArrayList<Blocks> ();
		for (int x=0;x<20;x++){
			for (int y=0;y<20;y++){
				if (!subImage[x][y].isSet()){
					empty.add(subImage[x][y]);
				}
			}
		}		
		return empty;
	}
		
	
	//public  synchronized void ResetBlock(Blocks block, String s){
		//this.subImage[block.getX()][block.getY()]=block;
		//this.subImage[block.getX()][block.getY()].BlockStamp=s;
		//this.subImage.[block.getX()][block.getY()].
	//}
}
