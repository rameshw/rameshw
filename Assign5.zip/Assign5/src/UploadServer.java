
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Class creates an upload server, finds available port and listens to peer connections
 * @author rameshweerakoon
 *
 */
public class UploadServer extends Thread implements Serializable{

		Socket sock;
		BufferedReader reader;
		String Adress;
		int port=8001;
		PeerList list;
		ImageBlocks blocks;
		ServerSocket ss=null;
			
		/**
		 * run method for thread
		 */
		public void run() {
					
			while(true){
				try {
				while(true){
					Socket peer=ss.accept();
					System.out.println("new peer connection");
					Uploader uploader=new Uploader(peer, list, blocks);
					uploader.start();
				}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}	
		}
		
		public UploadServer(PeerList list,ImageBlocks b){
			this.list=list;
			this.blocks=b;
				
			while(ss==null && port<65635){
				
				try {					
					ss=new ServerSocket(port);
					this.Adress=ss.getInetAddress().getHostAddress();
					System.out.println(port);
					break;
				} catch (IOException e) {
					e.printStackTrace();
				}					
				port++;
			}
		}
		
		/**
		 * return port number for uploD SERVER
		 * @return
		 */
		public int getPort(){
			return this.port;
		}
		
		/**
		 * Return port number for upload server
		 * @return
		 */
		public String getAddress(){
			return this.Adress;
		}
		
		public void resetBlock(ImageBlocks b){
			this.blocks=b;
		}
		
		
	}
