import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

/**
 * Creater a Main server instance
 * @author rameshweerakoon
 *
 */
public class ImageServer {
	JFrame frame;
	JButton change;
	MyCanvasServer canvas;
	Image image;
	BufferedImage subImage;
	PeerList list;
	Integer port;
	ImageBlocks blocks;
	String stamp;
	UploadServer peer;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ImageServer server=new ImageServer();
	}

	
	public ImageServer(){
		Date date=new Date();
		stamp=date.toString();
		System.out.println(stamp);
				
		frame=new JFrame("Image Server");
			
		subImage=new BufferedImage(400, 400, BufferedImage.TYPE_INT_ARGB);
		blocks=new ImageBlocks();
		
		JFileChooser jfc=new JFileChooser();
		jfc.showOpenDialog(null);
		if (jfc.getSelectedFile()!=null){	
				File file = new File(jfc.getSelectedFile().getPath());
				try {
					image = ImageIO.read(file).getScaledInstance(400, 400, Image.SCALE_FAST);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}				
		}else{
			frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
			System.exit(0);
		}
		int [][][] pixels=new int[20][20][400];
		
		Graphics g = subImage.getGraphics();
		g.drawImage(image, 0, 0, null);
		g.dispose();
		
		for (int i=0;i<20;i++){
			for (int j=0;j<20;j++){			
				BufferedImage temp=subImage.getSubimage(i*20, j*20, 20, 20);
				pixels[i][j] = temp.getRGB(0, 0, 20, 20, pixels[i][j], 0, 20);
				
				blocks.getBlock(i,j).setBlock(pixels[i][j],stamp);
				
			}
		}
		list=new PeerList();
		port=new Integer(8000);
		
		//Start upload server
		peer=new UploadServer(list, blocks);
		peer.start();
		
		
		canvas=new MyCanvasServer(image);
		change=new JButton("Load another image");
		change.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				Date date=new Date();
				stamp=date.toString();
				System.out.println(stamp);
				jfc.showOpenDialog(null);
				if (jfc.getSelectedFile()!=null){							
					File file = new File(jfc.getSelectedFile().getPath());
					try {
						subImage=new BufferedImage(400, 400, BufferedImage.TYPE_INT_ARGB);
						image = ImageIO.read(file).getScaledInstance(400, 400, Image.SCALE_FAST);
						Graphics g = subImage.getGraphics();
						g.drawImage(image, 0, 0, null);
						g.dispose();
						
						for (int i=0;i<20;i++){
							for (int j=0;j<20;j++){			
								BufferedImage temp=subImage.getSubimage(i*20, j*20, 20, 20);
								pixels[i][j] = temp.getRGB(0, 0, 20, 20, pixels[i][j], 0, 20);
								blocks.getBlock(i,j).setBlock(pixels[i][j],stamp);
							}
						}
					} catch (IOException e1) {
						//TODO Auto-generated catch block
						e1.printStackTrace();
					}	peer.resetBlock(blocks);
						canvas.setImage(image);
				}else{
					frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
					System.exit(0);
				}
				
				
			}
			
		});
		
		frame.add(canvas, BorderLayout.CENTER);
		frame.add(change, BorderLayout.SOUTH);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 400);
		frame.setVisible(true);
		
		
		Peers uploadserver= new Peers(peer.getAddress(), peer.getPort());
		
		//Start Sever for Main server
		Server sv=new Server(list, uploadserver);
		sv.start();
	}
	
}
