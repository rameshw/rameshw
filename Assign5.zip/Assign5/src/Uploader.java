import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Class creates an uploader for each peer and listens for requests
 * @author rameshweerakoon
 *
 */
public class Uploader extends Thread{
	Socket uploader;
	ObjectInputStream in;
	ObjectOutputStream out;
	Request request;
	PeerList list;
	ImageBlocks blocks;
	
	public Uploader(Socket s, PeerList list,ImageBlocks b){
		this.uploader=s;
		this.list=list;
		this.blocks=b;
		try {
			in = new ObjectInputStream(uploader.getInputStream());
			out = new ObjectOutputStream(uploader.getOutputStream());
			
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.uploader=s;
	}
	
	/**
	 * run method for thread
	 */
	public void run(){
		try{
			while((request=(Request) in.readObject())!=null){
				
				Blocks returnedBlock=null;
				//process request
				for(Blocks b : request.getRequiredBlocks()){
					if(blocks.getBlock(b.getX(), b.getY()).isSet()){
						returnedBlock= blocks.getBlock(b.getX(), b.getY());
						break;
					}
				}
				
				//send block 
				out.flush();
				out.writeObject(returnedBlock);
				
				//send new peerlist
				out.flush();
				out.writeObject(list);
				
				
				
			}
		}catch(IOException | ClassNotFoundException e){
			
		}
	}
	
}
