import java.io.Serializable;
import java.util.ArrayList;

/**
 * Class manages a request
 * @author rameshweerakoon
 *
 */
public class Request implements Serializable {
	private ArrayList<Blocks> req;
	
	public Request(ArrayList<Blocks> a){
		this.req=a;
	}
	
	/**
	 * return the set of required blocks
	 * @return
	 */
	public ArrayList<Blocks> getRequiredBlocks(){
		return this.req;
	}
}
