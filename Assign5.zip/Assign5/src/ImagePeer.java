import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 * Image Peers manages a Peers instance
 * @author rameshweerakoon
 *
 */
public class ImagePeer {

	JFrame frame;
	MyCanvasPeer canvas;
	PeerList list;
	UploadServer peer;
	ImageBlocks blocks;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ImagePeer server=new ImagePeer();
	}

	public ImagePeer(){
		frame=new JFrame("Image Peer");	
		blocks=new ImageBlocks();
		canvas=new MyCanvasPeer(blocks);
		String s="";
		JTextField label=new JTextField();
		while (s.equals("")){
		 s = (String)JOptionPane.showInputDialog(
                frame,
                "Connect to Server:\n",
                "Input",
                JOptionPane.OK_CANCEL_OPTION);

		 if ((s != null) && (s.length() > 0)) {
			System.out.println(s);
		 }else if (s==null){
			 //frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
			 System.exit(0);
		 }else{
			 s="";
		 }
		}
		frame.add(canvas, BorderLayout.CENTER);		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.setSize(400, 400);
		frame.setVisible(true);
		
		list=new PeerList();
		
		//starting upload server
		peer=new UploadServer(list, blocks);
		peer.start();
		
		Peers serverUploader=ConnectToServer(s, peer);
		
		//starting Downloader for server peer
		Downloader download=new Downloader(list, serverUploader.getAdd(), serverUploader.getPort(), peer.getAddress(), peer.getPort(),blocks, this.canvas);
		download.start();
	}
	
	/**
	 * Connect to main server and exchange port information
	 * @param s, time stamp
	 * @param peer, upload server of this peer to get port value
	 * @return, information of upload server for Main server
	 */
	public Peers ConnectToServer(String s, UploadServer peer){
		Peers serverUploader=null;
		try{
			Socket sock=new Socket(s, 8000);
			ObjectInputStream reader=new ObjectInputStream(sock.getInputStream());
			ObjectOutputStream writer=new ObjectOutputStream(sock.getOutputStream());

			writer.reset();
		    writer.writeObject(new Peers(peer.getAddress(), peer.getPort()));
		    writer.flush();
		    
			list=(PeerList) reader.readObject();
			serverUploader=(Peers) reader.readObject();
			//for(int i=0;i<list.getSize();i++){
				//System.out.println(list.getPeer(i).getAdd() + " " + list.getPeer(i).getPort());			
			//}
			reader.close();writer.close();
			sock.close();		
		}catch(IOException e){
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
		return serverUploader;
	}
	
	
}
