
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Class starts Main server and listens to peers
 * @author rameshweerakoon
 *
 */
public class Server extends Thread{
	PeerList list;
	ServerSocket server;
	ObjectOutputStream writer;
	ObjectInputStream reader;
	Peers upServer;
	public Server(PeerList list, Peers uploadserver){
		this.list=list;

		this.upServer=uploadserver;
		//setupNet();
	}
	
	/**
	 * run method for thread
	 */
	public void run(){

		try{
			
			//listen for connections
			server=new ServerSocket(8000);
			while (true){
				Socket ss=server.accept();
				
				writer=new ObjectOutputStream(ss.getOutputStream());
				reader=new ObjectInputStream(ss.getInputStream());
				
				Peers newinfo = (Peers) reader.readObject();
				
				list.addPeer(newinfo.getAdd(),newinfo.getPort());
				
				writer.reset();
				writer.writeObject(list);
				
				writer.reset();
				writer.writeObject(upServer);
				
				writer.flush();
				writer.close();reader.close();
			}
		}catch(IOException | ClassNotFoundException e){
			e.printStackTrace();
			System.exit(0);
		}
	}
	
}
