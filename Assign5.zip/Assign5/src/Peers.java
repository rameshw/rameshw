import java.io.Serializable;
import java.net.InetAddress;

/**
 * Class stores information of peer
 * @author rameshweerakoon
 *
 */
public class Peers implements Serializable{
	private String address;
	private int port;
	private int id;
	public Peers(String add, int p){
		this.id=0;
		this.address=add;
		this.port=p;
	}
	
	/**
	 * Address of peer
	 * @return string
	 */
	public String getAdd(){
		return this.address;	
	}
	
	/**
	 * Port number of peer
	 * @return integer
	 */
	public int getPort(){
		return this.port;
		
	}
	
	/**
	 * setID of peer
	 * @param id, id of peer
	 */
	public void setID(int id){
		 this.id=id;
		
	}
}
