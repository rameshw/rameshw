import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * Canvas to draw on for peers
 * @author rameshweerakoon
 *
 */
public class MyCanvasPeer extends JPanel{
	BufferedImage img;
	ImageBlocks blocks;
	public MyCanvasPeer(ImageBlocks b){
		this.blocks=b;
		this.img=new BufferedImage(400, 400, BufferedImage.TYPE_INT_ARGB);
	}
	
	/**
	 * Function called when repainted
	 */
	public void paintComponent(Graphics g){
		
		Blocks block;
		for (int x=0; x<20;x++){
			for (int y=0;y<20;y++){
				 block=blocks.getBlock(x, y);	
				 if(block.isSet()){
					 img.setRGB(block.getX()*20, block.getY()*20, 20, 20, block.getImg(), 0, 20);
					 g.drawImage(img, 0, 0,  null);
				 }
				
			}
		}
	}
	
	/**
	 * set New Image for canvas
	 * @param b, blocks
	 */
	public void newImage(ImageBlocks b){
		this.blocks=b;
		this.img=new BufferedImage(400, 400, BufferedImage.TYPE_INT_ARGB);
	}
	
	
	
	
}
