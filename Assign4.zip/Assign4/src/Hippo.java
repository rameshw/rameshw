import javax.swing.ImageIcon;



/**
 * Subclass for Animals of Hippo type
 * @author rameshweerakoon
 *
 */
public class Hippo extends Animal{
	/**
	 * Name of Hippo
	 */
	public  static  char name='h';
	/**
	 * Location of Icon
	 */
	public  static String icon;
	
	/**
	 * Constructor for Hippo
	 * @param x, <code>x</code> is x-coordinate of each Hippo
	 * @param y, <code>y</code> is y-coordinate of each Hippo
	 */
	public Hippo(int x, int y) {
		super('h',x,y);
		System.out.println(this.getClass().getSimpleName()+" initialized at " + x +", "+y);
	}
	
	/**
	 * change location of icon
	 * @param a, new location of string
	 */
	public static void changeIcon(String a){
		Hippo.icon = a;
	}
	
	/**
	 * get location of Icon
	 * @return string, location of icon
	 */
	public static String getIcon(){
		return Hippo.icon ;
	}
}
