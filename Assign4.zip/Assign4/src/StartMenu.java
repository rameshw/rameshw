import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;
	
/**
 * StartMenu helps initial menu that allows to move to forestGUI
 * @author rameshweerakoon
 *
 */
public class StartMenu {
	
	private JFrame frame;
	private JPanel panel;
	private JButton Start;
	private JCheckBox cDog, cWolf, cFox, cLion, cTiger, cHippo, cCat;
	private ImageIcon iDog, iFox, iWolf, iLion, iTiger, iHippo, iCat;		
	private JButton bDog, bFox, bWolf, bCat, bLion, bTiger, bHippo;
	private JLabel lDog, lFox, lWolf, lCat, lLion, lTiger, lHippo;
	
	/**
	 * Constructor for startMenu
	 */
	public StartMenu(){
		panel=new JPanel();
		Start= new JButton("Start");
		Start.addActionListener(new NextMenuListener());
		panel.setLayout(new GridLayout(8,3,3,3));
		
		cDog= new JCheckBox("Dog", true);
		iDog = new ImageIcon("Icons/Dog.png");		
		bDog = new JButton("Pick an alternate icon"); bDog.setSize(new Dimension(100, 40));
		bDog.addActionListener(new IconListener("Dog"));
		lDog = new JLabel(iDog);
		panel.add(cDog); panel.add(lDog);panel.add(bDog);
		Dog.changeIcon("Icons/Dog.png");
		
		 cFox= new JCheckBox("Fox", true);
		 iFox = new ImageIcon("Icons/Fox.png");
		 bFox = new JButton("Pick an alternate icon"); bFox.setSize(new Dimension(100, 40));
		 bFox.addActionListener(new IconListener("Fox"));
		 lFox = new JLabel(iFox);
		panel.add(cFox); panel.add(lFox);panel.add(bFox);
		Fox.changeIcon("Icons/Fox.png");
		
		 cWolf= new JCheckBox("Wolf", true);
		 iWolf = new ImageIcon("Icons/Wolf.png");
		 bWolf = new JButton("Pick an alternate icon"); bWolf.setSize(new Dimension(100, 40));
		 bWolf.addActionListener(new IconListener("Wolf"));
		 lWolf = new JLabel(iWolf);
		panel.add(cWolf); panel.add(lWolf);panel.add(bWolf);
		Wolf.changeIcon("Icons/Wolf.png");
		
		 cCat= new JCheckBox("Cat", true);
		 iCat = new ImageIcon("Icons/Cat.png");
		 bCat = new JButton("Pick an alternate icon"); bCat.setSize(new Dimension(100, 40));
		 bCat.addActionListener(new IconListener("Cat"));
		 lCat = new JLabel(iCat);
		panel.add(cCat); panel.add(lCat);panel.add(bCat);
		Cat.changeIcon("Icons/Cat.png");
		
		 cLion= new JCheckBox("Lion", true);
		 iLion = new ImageIcon("Icons/Lion.png");
		 bLion = new JButton("Pick an alternate icon");bLion.setSize(new Dimension(100, 40));
		 bLion.addActionListener(new IconListener("Lion"));
		 lLion = new JLabel(iLion);
		panel.add(cLion); panel.add(lLion);panel.add(bLion);
		Lion.changeIcon("Icons/Lion.png");
		
		 cTiger= new JCheckBox("Tiger", true);
		 iTiger = new ImageIcon("Icons/Tiger.png");
		 bTiger = new JButton("Pick an alternate icon");bTiger.setSize(new Dimension(100, 40));
		 bTiger.addActionListener(new IconListener("Tiger"));
		 lTiger = new JLabel(iTiger);
		panel.add(cTiger); panel.add(lTiger);panel.add(bTiger);
		Tiger.changeIcon("Icons/Tiger.png");
		
		 cHippo= new JCheckBox("Hippo", true);
		 iHippo = new ImageIcon("Icons/Hippo.png");
		 bHippo = new JButton("Pick an alternate icon");bHippo.setSize(new Dimension(100, 40));
		 bHippo.addActionListener(new IconListener("Hippo"));
		 lHippo = new JLabel(iHippo);
		panel.add(cHippo); panel.add(lHippo);panel.add(bHippo);
		Hippo.changeIcon("Icons/Hippo.png");
		
		this.frame=new JFrame("Setup");
		this.frame.getContentPane().setLayout(new BorderLayout());
		this.frame.add(BorderLayout.CENTER,panel);
		this.frame.add(BorderLayout.SOUTH,Start);
		
		this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.frame.setSize(500, 400);
		this.frame.setVisible(true);
		
	}
	
	/**
	 * Class for actionlistener to button
	 * @author rameshweerakoon
	 *
	 */
	class NextMenuListener implements ActionListener{
		
		@Override
		/**
		 * function run if start button clicked
		 * @param e is the event
		 */
		public void actionPerformed(ActionEvent e) {
			ArrayList<Character> live=new ArrayList<Character>();
			
			if(cDog.isSelected())
				live.add('d');
		
			if(cFox.isSelected())
				live.add('f');
			
			if(cWolf.isSelected())
				live.add('w');
			
			if(cCat.isSelected())
				live.add('c');
			
			if(cLion.isSelected())
				live.add('l');
			
			if(cTiger.isSelected())
				live.add('t');
			
			if(cHippo.isSelected())
				live.add('h');
			
			ForestGUI forest=new ForestGUI(live);
			frame.dispose();		
		}
	}
	 
	JFileChooser jfc=new JFileChooser();
	
	/**
	 * class that helps select new icon for animals
	 * @author rameshweerakoon
	 *
	 */
	class IconListener implements ActionListener{
		private String Icon;
		
		public IconListener(String a){
				this.Icon=a;
		}
		
		@Override
		/**
		 *function run if change Icon button is clicked
		 * @param e is the event 
		 */
		public void actionPerformed(ActionEvent e) {
			jfc.showOpenDialog(null);
			if (jfc.getSelectedFile()!=null){			
				if(this.Icon.equals("Dog")){
					ImageIcon newI = new ImageIcon(jfc.getSelectedFile().getPath());
					lDog.setIcon(newI);
					Dog.changeIcon(jfc.getSelectedFile().getPath());
				}else if(this.Icon.equals("Fox")){
					ImageIcon newI = new ImageIcon(jfc.getSelectedFile().getPath());
					lFox.setIcon(newI);
					Fox.changeIcon(jfc.getSelectedFile().getPath());
				}else if(this.Icon.equals("Wolf")){
					ImageIcon newI = new ImageIcon(jfc.getSelectedFile().getPath());
					lWolf.setIcon(newI);
					Wolf.changeIcon(jfc.getSelectedFile().getPath());
				}else if(this.Icon.equals("Cat")){
					ImageIcon newI = new ImageIcon(jfc.getSelectedFile().getPath());
					lCat.setIcon(newI);
					Cat.changeIcon(jfc.getSelectedFile().getPath());
				}else if(this.Icon.equals("Lion")){
					ImageIcon newI = new ImageIcon(jfc.getSelectedFile().getPath());
					lLion.setIcon(newI);
					Lion.changeIcon(jfc.getSelectedFile().getPath());
				}else if(this.Icon.equals("Tiger")){
					ImageIcon newI = new ImageIcon(jfc.getSelectedFile().getPath());
					lTiger.setIcon(newI);
					Tiger.changeIcon(jfc.getSelectedFile().getPath());
				}else if(this.Icon.equals("Hippo")){
					ImageIcon newI = new ImageIcon(jfc.getSelectedFile().getPath());
					lHippo.setIcon(newI);
					Hippo.changeIcon(jfc.getSelectedFile().getPath());
				}
			}
		}
	}
	
	
	
}
