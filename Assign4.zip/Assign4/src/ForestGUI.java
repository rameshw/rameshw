import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

/**
 * Class draws forestGUI
 * @author rameshweerakoon
 *
 */
public class ForestGUI {
	private JFrame frame;
	private JPanel panel;	
	private JButton Auto;
	Forest forest;
	Animal[] animals;
	ArrayList<Character> aLive;
	
	/**
	 * constructor for forestGUI
	 * @param a, char of animals in forest
	 */
	public ForestGUI(ArrayList<Character> a){
		aLive= new ArrayList<Character>();
		aLive=a;
		frame=new JFrame("Forest");
		init();
	}
	
	private void init(){
		this.panel=new MyCanvas();
		this.panel.setLayout(new BorderLayout());
		Auto=new JButton("Auto Mode");
		Auto.addMouseListener(new AutoListener());
		this.frame.getContentPane().setLayout(new BorderLayout());
		this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		addAnimals();
		this.panel= new MyCanvas();
		this.panel.addMouseListener((MouseListener) this.panel);
		this.panel.addMouseMotionListener((MouseMotionListener) this.panel);

		this.frame.add(BorderLayout.CENTER,this.panel);
		
		this.frame.add(BorderLayout.SOUTH,Auto);
		this.frame.setSize(650, 680);
		this.frame.setVisible(true);
	}
	
	private void addAnimals(){
		System.out.println("----------Start----------");	
		animals=new Animal[aLive.size()];		
		forest = new Forest(animals, aLive);
	}
	
	private void StartAgain(){
		System.out.println("----------Start----------");	
		animals=new Animal[7];		
		this.aLive=new ArrayList<Character>();
		this.aLive.add('d');
		this.aLive.add('f');
		this.aLive.add('w');
		this.aLive.add('c');
		this.aLive.add('l');
		this.aLive.add('t');
		this.aLive.add('h');
		forest = new Forest(animals, aLive);

		panel.repaint();

	}
	
	
	/**
	 * Class listens to Auto button click
	 * @author rameshweerakoon
	 *
	 */
	class AutoListener extends MouseAdapter{
		/**
		 * function run when mouse released
		 */
		public void mouseReleased(MouseEvent e){
			boolean a=false;
			while(a==false){
					a=forest.move(animals);
					
					panel.paintImmediately(0, 0, 600, 600);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e1) {

					}
			}
			
			if (a){
				StartAgain();
			}
		}
		
	}
		
	/**
	 * Class draws paints forest and listens to louse events
	 * @author rameshweerakoon
	 *
	 */
		class MyCanvas extends JPanel implements MouseListener, MouseMotionListener{
			
			private int x=-1,y=-1;
			private int x1=-1,y1=-1;
			
			/**
			 * when mouse is pressed on the forest
			 */
			public void mousePressed(MouseEvent e){
				 this.x=e.getX()/40;
				 this.y=e.getY()/40;
				
				if (this.x<15 && this.y<15 && !Character.toString(forest.arrayF[this.x][this.y]).equals(".")){
					panel.repaint();
				}
			}
			
			/**
			 * when mouse is released on the forest
			 */
			public void mouseReleased(MouseEvent e){
				//System.out.println(",");
				this.x1=e.getX()/40;
				 this.y1=e.getY()/40;
				ArrayList<Coordinates> locations; 
				if (this.x!=this.x1 || this.y1!=this.y ){	
					//System.out.println(x +"," + y);
					int b=Forest.getIforAnimal(forest.arrayF[this.x][this.y], animals);
					locations=animals[b].getAllLocs();
					for(int n=0;n<locations.size();n++){
						if(locations.get(n).getX()==this.x1 && locations.get(n).getY()==this.y1){
							boolean a=forest.ManualMove(animals, animals[b],this.x1,this.y1);
							if (a){
								StartAgain();
							}
						}					
					}
						
						
						
				}
				this.x=-1;
				this.y=-1;
				this.x1=-1;
				this.y1=-1;
				panel.repaint();
			}
			
			/**
			 * function called to repaint forest
			 */
			public void paint(Graphics g) {
				ArrayList<Coordinates> locations; 
				for (int i=0; i<15;i++){
					for(int j=0;j<15;j++){
						g.setColor(Color.black);
						g.drawRect(i*40, j*40, 40, 40);
						
						if (!Character.toString(forest.arrayF[i][j]).equals(".")){
							int a=Forest.getIforAnimal(forest.arrayF[i][j], animals);
							ImageIcon img;
							if(animals[a] instanceof Dog){
								 img=new ImageIcon(Dog.getIcon());
							}else if(animals[a] instanceof Fox){
								 img=new ImageIcon(Fox.getIcon());
							}else if(animals[a] instanceof Wolf){
								 img=new ImageIcon(Wolf.getIcon());
							}else if(animals[a] instanceof Cat){
								 img=new ImageIcon(Cat.getIcon());
							}else if(animals[a] instanceof Lion){
								 img=new ImageIcon(Lion.getIcon());
							}else if(animals[a] instanceof Tiger){
								 img=new ImageIcon(Tiger.getIcon());
							}else {
								 img=new ImageIcon(Hippo.getIcon());
							}				
							g.drawImage(img.getImage(), (i)*40, (j)*40,40,40, null);							
						}					
					}
				}
								
			if(this.x!=-1 && this.y!=-1){
					if (!Character.toString(forest.arrayF[this.x][this.y]).equals(".")){	

						int b=Forest.getIforAnimal(forest.arrayF[this.x][this.y], animals);
						//get list of possible locations								
						locations=animals[b].getAllLocs();
						
						for(int n=0;n<locations.size();n++){
							if(locations.get(n).getY()==this.y1 && locations.get(n).getX()==this.x1){
								g.setColor(Color.blue);
								g.fillRect(this.x1*40, this.y1*40, 39, 39);
							}else if(!Character.toString(forest.arrayF[locations.get(n).getX()][locations.get(n).getY()]).equals(".")){
								g.setColor(Color.red);
								g.fillRect(locations.get(n).getX()*40, locations.get(n).getY()*40, 39, 39);
							}else{
								g.setColor(Color.orange);
								g.fillRect(locations.get(n).getX()*40, locations.get(n).getY()*40, 39, 39);
							}						
						}		
				}
			}
		}
			
			@Override
			/**
			 * function called when mouse clicked
			 */
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
			}

			@Override
			/**
			 * function called when mous  entered
			 */
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub	
			}

			@Override
			/**
			 * function called when mouse exited
			 */
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub		
			}

			@Override
			/**
			 * function called when mouse dragged
			 */
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub
				this.x1=e.getX()/40;
				 this.y1=e.getY()/40;
				if (this.x1<15 && this.y1<15){
					panel.repaint();
				}
			}

			@Override
			/**
			 * function called when mouse moved
			 */
			public void mouseMoved(MouseEvent e) {
				// TODO Auto-generated method stub
			}			
		}
}
