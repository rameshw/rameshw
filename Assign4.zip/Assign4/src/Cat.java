import javax.swing.ImageIcon;



/**
 * Subclass for Animals of Cat type
 * @author rameshweerakoon
 *
 */
public class Cat extends Feline{
	/**
	 * Name of Cat
	 */
	public  static  char name='c';
	
	/**
	 * Location of Icon
	 */
	public  static String icon;
	
	/**
	 * Constructor for Cat
	 * @param x, <code>x</code> is x-coordinate of each Cat
	 * @param y, <code>y</code> is y-coordinate of each Cat
	 */
	public Cat( int x, int y) {
		super('c',x,y);
		abc=0;
		System.out.println(this.getClass().getSimpleName()+" initialized at " + x +", "+y);
	}
	
	/**
	 * change location of icon
	 * @param a, new location of string
	 */
	public static void changeIcon(String a){
		Cat.icon = a;
	}
	
	/**
	 * get location of Icon
	 * @return string, location of icon
	 */
	public static String getIcon(){
		return Cat.icon ;
	}

}
