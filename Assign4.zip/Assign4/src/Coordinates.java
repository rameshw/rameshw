/**
 * Stores Coordinates of animal
 * @author rameshweerakoon
 *
 */
public class Coordinates {
	private int x;
	private int y;
	
	/**
	 * set initial locations
	 * @param x, set x Coordinate
	 * @param y, set y Coordinate
	 */
	public Coordinates(int x,int y){
		this.x=x;
		this.y=y;	
	}
	
	/**
	 * return the x coordinate
	 * @return x coordinate
	 */
	public int getX(){
		return this.x;
	}
	
	/**
	 * return the y coordinate
	 * @return y coordinate
	 */
	public int getY(){
		return this.y;
	}
}
