
import java.util.ArrayList;
import java.util.Random;

/**
 * Subclass for Animals of Feline type
 * @author rameshweerakoon
 *
 */
public abstract class Feline extends Animal{
	
	/**
	 * Constructor for Feline
	 * @param name, <code>name</code> is name of each Feline
	 * @param x, <code>x</code> is x-coordinate of each Feline
	 * @param y, <code>y</code> is y-coordinate of each Feline
	 */
	public Feline(char name, int x, int y) {
		super(name,x,y);
	}
	
	/**
	 * Function generates possible new location of animal
	 * @return new location of Animal
	 */
	public int[] getALoc(){
		boolean bInside=false;
		char[] cDir={'r','l','u','d','w','x','y','z'};//w= right up, x=left up, y=right down, z=left down
		Random rand = new Random();
		int[] iNewXY=new int[2];

		while(bInside==false){
			int iChar=rand.nextInt(8); 		//pick a direction
			//check if its inside forest
			if (cDir[iChar]=='r' && super.x-1>=0){
				bInside=true;
				iNewXY[0]=super.x-1;
				iNewXY[1]=super.y;
			}else if (cDir[iChar]=='l' && super.x+1<=14){
				bInside=true;
				iNewXY[0]=super.x+1;
				iNewXY[1]=super.y;
			}else if (cDir[iChar]=='u' && super.y-1>=0){
				bInside=true;
				iNewXY[0]=super.x;
				iNewXY[1]=super.y-1;
			}else if (cDir[iChar]=='d' && super.y+1<=14){
				bInside=true;
				iNewXY[0]=super.x;
				iNewXY[1]=super.y+1;
			}else if (cDir[iChar]=='w' && super.x-1>=0 && super.y-1>=0){
				bInside=true;
				iNewXY[0]=super.x-1;
				iNewXY[1]=super.y-1;
			}else if (cDir[iChar]=='x' && super.x+1<=14 && super.y-1>=0){
				bInside=true;
				iNewXY[0]=super.x+1;
				iNewXY[1]=super.y-1;
			}else if (cDir[iChar]=='y' && super.x-1>=0 && super.y+1<=14){
				bInside=true;
				iNewXY[0]=super.x-1;
				iNewXY[1]=super.y+1;
			}else if (cDir[iChar]=='z' && super.x+1<=14 && super.y+1<=14){
				bInside=true;
				iNewXY[0]=super.x+1;
				iNewXY[1]=super.y+1;
			}else{
				bInside=false;
			}
		}
			return iNewXY;
	}
	
	/**
	 * Function attack for each Feline
	 * @param a, <code>a</code> is the Animal being attacked
	 * @return Animal winner
	 */
	public Animal attack(Animal a){
		if ((a instanceof Canine)){		//if animal being attacked is Canine
			System.out.println( this.getClass().getSimpleName() + " from " + super.x +", " + super.y 
					+" attacks " + a.getClass().getSimpleName() + " at " +  a.getX() +", "+ a.getY() + " and wins");
			System.out.println(a.getClass().getSimpleName() + " dies at " + a.getX() + ", " + a.getY());
			return this;
		}else{			//else refer super class function
			Animal winner=super.attack(a);
			return winner;
		}
	}
	
	/**
	 * method returns a list of all possible location of an animal
	 * @return ArrayList of possible coordinates
	 */
	public ArrayList<Coordinates> getAllLocs(){
		ArrayList<Coordinates> allLoc=new ArrayList<Coordinates>();
		Integer[] loc=new Integer[2];
				
		if (this.x-1>=0){		
			loc[0]=this.x-1;
			loc[1]=this.y;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.x+1<=14){			
			loc[0]=this.x+1;
			loc[1]=this.y;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.y-1>=0){			
			loc[0]=this.x;
			loc[1]=this.y-1;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.y+1<=14){			
			loc[0]=this.x;
			loc[1]=this.y+1;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		
		if (this.x-1>=0 && this.y-1>=0){		
			loc[0]=this.x-1;
			loc[1]=this.y-1;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.x+1<=14 && this.y-1>=0){		
			loc[0]=this.x+1;
			loc[1]=this.y-1;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}	
		if (this.x+1<=14 && this.y+1<=14){		
			loc[0]=this.x+1;
			loc[1]=this.y+1;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.x-1>=0 && this.y+1<=14){		
			loc[0]=this.x-1;
			loc[1]=this.y+1;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		return allLoc;
	}
}
