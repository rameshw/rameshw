package abc;
import PeerList;
import UploadServer;

import java.awt.image.BufferedImage;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;


public class ServerPeer extends Thread{
	PeerList list;
	BufferedImage[][] subImage;
	ServerSocket server;
	ObjectOutputStream writer;
	
	public ServerPeer(PeerList list,BufferedImage[][] subImage){
		this.list=list;
		this.subImage=subImage;
		
	}
	
	public void run(){
		UploadServer upload=new UploadServer(list, subImage);
		upload.run();
	}
}
