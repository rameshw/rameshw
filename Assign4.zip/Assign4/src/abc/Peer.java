package abc;

import PeerList;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class Peer {

	BufferedImage image;
	Socket sock;
	ServerSocket ss=null;
	ObjectInputStream reader;
	ObjectOutputStream writer;
	PeerList list;
	BufferedImage[][] subImage;
	

	
	public Peer(BufferedImage[][] img){
		//image=new BufferedImage();
		if (img!=null){
			this.subImage=img;
		}else{
			this.subImage=new BufferedImage[20][20];
		}
		
		setupNetworking();
	}
	
	public void setupNetworking(){
		//Thread t=new Thread(new InReader());
		//t.start();
		int port=8000;
		
		try{
			
			//creating upload server
			//UploadServer uploadServer=new UploadServer();
			//Thread upServer=new Thread(uploadServer);
			//upServer.run();
			
			sock=new Socket("127.0.0.1", 8000);
			reader=new ObjectInputStream(sock.getInputStream());
			writer=new ObjectOutputStream(sock.getOutputStream());
			//writer.writeObject(new Peers(sock.getInetAddress().getHostAddress(), sock.getPort()));
			list=(PeerList) reader.readObject();
			int ServerUpload=(int) reader.readObject();
			reader.close();
			writer.close();sock.close();
			
			
		}catch(IOException e){
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
