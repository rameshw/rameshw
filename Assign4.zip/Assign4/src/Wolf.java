import javax.swing.ImageIcon;

/**
 * Subclass for Animals of Wolf type
 * @author rameshweerakoon
 *
 */
public class Wolf extends Canine{
	/**
	 * Name of wolf
	 */
	public  static  char name='w';
	/**
	 * Location of Icon
	 */
	public  static String icon;
	
	/**
	 * Constructor for Wolf
	 * @param x, <code>x</code> is x-coordinate of each Wolf
	 * @param y, <code>y</code> is y-coordinate of each Wolf
	 */
	public Wolf(int x, int y) {
		super('w',x,y);
		System.out.println(this.getClass().getSimpleName()+" initialized at " + x +", "+y);
	}
	
	/**
	 * change location of icon
	 * @param a, new location of string
	 */
	public static void changeIcon(String a){
		Wolf.icon = a;
	}
	
	/**
	 * get location of Icon
	 * @return string, location of icon
	 */
	public static String getIcon(){
		return Wolf.icon ;
	}
}
