
/**
 * Class AnimalGUI help create a startmenu
 * @author rameshweerakoon
 *
 */
public class AnimalGUI {

	/**
	 * Main method, starting point
	 * @param args, not used
	 */
	public static void main(String[] args) {
		AnimalGUI myGUI= new AnimalGUI();
	}
	
	/**
	 * Constructor for AnimalGUI
	 */
	public AnimalGUI(){
		StartMenu start= new StartMenu();
		
	}
	
	
}
