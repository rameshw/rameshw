import java.awt.Image;

import javax.swing.ImageIcon;



/**
 * Subclass for Animals of Dog type
 * @author rameshweerakoon
 *
 */
public class Dog extends Canine{
	/**
	 * Name of Dog
	 */
	public  static  char name='d';
	
	/**
	 * Location of Icon
	 */
	public static  String icon;
	
	/**
	 * Constructor for Dog
	 * @param x, <code>x</code> is x-coordinate of each Dog
	 * @param y, <code>y</code> is y-coordinate of each Dog
	 */
	public Dog(int x, int y) {
		super('d',x,y);
		System.out.println(this.getClass().getSimpleName()+" initialized at " + x +", "+y);
	}
	
	/**
	 * change location of icon
	 * @param a, new location of string
	 */
	public static void changeIcon(String a){
		//super.
		Dog.icon = a;
	}
	
	/**
	 * get location of Icon
	 * @return string, location of icon
	 */
	public static String getIcon(){
		return Dog.icon ;
	}

}
