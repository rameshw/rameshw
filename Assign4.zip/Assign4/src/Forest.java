
import java.util.ArrayList;
import java.util.Random;

/**
 * Forest class contains forest to array to store animals and other functions
 * @author rameshweerakoon
 *
 */
public class Forest {
	
	/**
	 * Check position of animals in array
	 * @param aAnimal  <code>aAnimal</code> is the name of the animal to be matched
	 * @param animals  <code>animals</code> is the array of the animal to be searched
	 * @return <code>I</code> is the index of the animals found
	 */
	public static int getIforAnimal(char aAnimal, Animal[] animals){
		int I=0;
		for (int i=0; i<animals.length;i++){
			if (Character.toString(animals[i].getName()).equals(String.valueOf(aAnimal))){
				I=i;
				break;
			}
		}
		return I;
	}
		
	/**
	 * function creates 7 distinct x,y coordinates
	 * @return <code>iNewLoc</code> array of 7 coordinates
	 */
	public static int[][]  getNewInitLoc(){
		int[][] iNewLoc=new int[2][7];
		Random rand = new Random();
		int randomX=rand.nextInt(FSize);
		int randomY=rand.nextInt(FSize);
		iNewLoc[0][0]=randomX;
		iNewLoc[1][0]=randomY;
		boolean MatchFound=true;
		for (int i=1;i<7;i++){
			//check if match found	
			while (MatchFound==true){
				randomX=rand.nextInt(FSize);
				randomY=rand.nextInt(FSize);
					
				for (int j=0;j<=i-1;j++){	
					if (randomX==iNewLoc[0][j] && randomY==iNewLoc[1][j]){
						MatchFound=true;
						break;
					}else if(j==i-1){		//no match found, add to array
						iNewLoc[0][i]=randomX;
						iNewLoc[1][i]=randomY;
						MatchFound=false;
					}
				}		
			}
			MatchFound=true;
		}
			return iNewLoc;
		}
		
	/**
	 * Array of forest
	 */
	public char[][] arrayF;
	private final static int FSize=15;
	
	/**
	 * constructor for Forest
	 */
	public Forest(Animal animals[], ArrayList<Character> a){
		this.arrayF = new char[FSize][FSize];
		for (int i=0;i<FSize;i++){
			for (int j=0;j<FSize;j++){
				this.arrayF[i][j]='.';
			}
		}	
		int[][] randXY;
		randXY=Forest.getNewInitLoc();
		//for ()
		for(int i=0;i<a.size();i++){
			if(a.get(i).equals('d')){
				animals[i]=new Dog(randXY[0][i],randXY[1][i]);
			}else if(a.get(i).equals('f')){
				animals[i]=new Fox(randXY[0][i],randXY[1][i]);
			}else if(a.get(i).equals('w')){
				animals[i]=new Wolf(randXY[0][i],randXY[1][i]);
			}else if(a.get(i).equals('c')){
				animals[i]=new Cat(randXY[0][i],randXY[1][i]);
			}else if(a.get(i).equals('t')){
				animals[i]=new Lion(randXY[0][i],randXY[1][i]);
			}else if(a.get(i).equals('l')){
				animals[i]=new Tiger(randXY[0][i],randXY[1][i]);
			}else if(a.get(i).equals('h')){
				animals[i]=new Hippo(randXY[0][i],randXY[1][i]);
			}
							
		}
		//add name of animal to location in forest
		for (int i=0;i<a.size();i++){
			this.arrayF[animals[i].getX()][animals[i].getY()]=animals[i].getName();
		}
	}
	
	/**
	 * prints out Forest with animal locations
	 */
	public void print_Forest(){
		for (int i=0;i<FSize;i++){
			for (int j=0;j<FSize;j++){
				System.out.print(this.arrayF[i][j]);
			}
			System.out.print("\n");
		}
	}
	
	/**
	 * returns array of live animals
	 * @return <code>temp</code> is the array of live animals
	 */
	public char[] LiveAnimals(){		
		char[] temp;
		int count=0;
		//count animals
		for (int i=0;i<FSize;i++){
			for (int j=0;j<FSize;j++){
				if (!Character.toString(this.arrayF[i][j]).equals(".")){
					count++;
				}
			}
		}	
		//create array
		temp=new char[count];
		count=0;
		//add chars of animals to array
		for (int i=0;i<FSize;i++){
			for (int j=0;j<FSize;j++){
				if (!Character.toString(this.arrayF[i][j]).equals(".")){
					temp[count]=this.arrayF[i][j];
					count++;
				}
			}
		}
		return temp;
	}
	
	/**
	 * Move animals in Auto mode
	 * @param animals, list of animals to move
	 * @return true if only one survivor,false otherwise
	 */
	public boolean move(Animal animals[]){
		char[] cLiveAnimals=new char[7];
		
		//get list of currently live animals
		cLiveAnimals=this.LiveAnimals();
		int iThisAnimal;
		int iPrey;
		//while(cLiveAnimals.length>1) {				
			//move all alive animals
			for (int i=0;i<cLiveAnimals.length;i++){
				char thisAnimal=Character.valueOf(cLiveAnimals[i]);
				iThisAnimal=Forest.getIforAnimal(thisAnimal, animals);		//get i of current animal
				if (!Character.toString(this.arrayF[animals[iThisAnimal].getX()][animals[iThisAnimal].getY()]).equals(Character.toString(animals[iThisAnimal].getName())) ){
					//if animal has already died
					continue;
				}
				int[] iNewXY=new int[2];
				iNewXY=animals[iThisAnimal].getALoc();
				
				//if new location is empty, move the animal
				if (Character.toString(this.arrayF[iNewXY[0]][iNewXY[1]]).equals(".")){
					this.arrayF[iNewXY[0]][iNewXY[1]]=animals[iThisAnimal].getName();
					this.arrayF[animals[iThisAnimal].getX()][animals[iThisAnimal].getY()]='.';						
					System.out.println( animals[iThisAnimal].getClass().getSimpleName()+ " moved from " + animals[iThisAnimal].getX() +", " + animals[iThisAnimal].getY() 
						+" to " + iNewXY[0] +", "+ iNewXY[1]);
					animals[iThisAnimal].move(iNewXY[0], iNewXY[1]);
				}else{ 					//if new location have a animal, attack!
					iPrey=Forest.getIforAnimal(this.arrayF[iNewXY[0]][iNewXY[1]], animals);
					//get winner of fight
					Animal winner=animals[iThisAnimal].attack(animals[iPrey]);
					if (winner==animals[iPrey]){
						this.arrayF[animals[iThisAnimal].getX()][animals[iThisAnimal].getY()]='.'; //when attacker dies
					}else{
						this.arrayF[animals[iThisAnimal].getX()][animals[iThisAnimal].getY()]='.';
						animals[iThisAnimal].move(iNewXY[0], iNewXY[1]);		//move winner to new locations
						this.arrayF[iNewXY[0]][iNewXY[1]]=winner.getName();	
					}
				}
			}				
			cLiveAnimals=this.LiveAnimals();	//new list of live animals
			//this.print_Forest();					//print forest
		//}		
		if(cLiveAnimals.length==1){
			System.out.println("-----------End-----------");
			char thisAnimal=Character.valueOf(cLiveAnimals[0]);
			iThisAnimal=Forest.getIforAnimal(thisAnimal, animals);
			System.out.println("The survivor is " + animals[iThisAnimal].getClass().getSimpleName() + " at " + animals[iThisAnimal].getX() +", " + animals[iThisAnimal].getY() );
			return true;
		}
		return false;
	}
	
	/**
	 * Move an animal in manual mode
	 * @param animals, list of animals 
	 * @param a, specific animal to move
	 * @param newX, new x location
	 * @param newY, new y location
	 * @return true if only one survivor,false otherwise
	 */
	public boolean ManualMove (Animal[] animals,Animal a,int newX, int newY){
		//if new location is empty, move the animal
		//System.out.println("here");
		int iPrey;
		if (Character.toString(this.arrayF[newX][newY]).equals(".")){
			this.arrayF[newX][newY]=a.getName();
			this.arrayF[a.getX()][a.getY()]='.';						
			System.out.println( a.getClass().getSimpleName()+ " moved from " + a.getX() +", " + a.getY() 
				+" to " + newX +", "+ newY);
			a.move(newX, newY);
		}else{ 					//if new location has a animal, attack!
			iPrey=Forest.getIforAnimal(this.arrayF[newX][newY], animals);
			//get winner of fight
			Animal winner=a.attack(animals[iPrey]);
			if (winner==animals[iPrey]){
				this.arrayF[a.getX()][a.getY()]='.'; //when attacker dies
			}else{
				this.arrayF[a.getX()][a.getY()]='.';
				a.move(newX, newY);		//move winner to new locations
				this.arrayF[newX][newY]=winner.getName();	
			}
		}
		char[] cLiveAnimals=new char[7];
		int iThisAnimal;
		cLiveAnimals=this.LiveAnimals();
		if(cLiveAnimals.length==1){
			System.out.println("-----------End-----------");
			char thisAnimal=Character.valueOf(cLiveAnimals[0]);
			iThisAnimal=Forest.getIforAnimal(thisAnimal, animals);
			System.out.println("The survivor is " + animals[iThisAnimal].getClass().getSimpleName() + " at " + animals[iThisAnimal].getX() +", " + animals[iThisAnimal].getY() );
			return true;
		}
		return false;
	}
}
