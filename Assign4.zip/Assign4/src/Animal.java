

import java.awt.Image;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;

/**
 * Animal is the super class for all animals
 * @author rameshweerakoon
 *
 */
public abstract class Animal {
	protected int x;
	protected int y;
	private char name;
	protected int abc;
	/**
	 * Constructor for Animal
	 * @param name, <code>name</code> is name of each animal
	 * @param x, <code>x</code> is x-coordinate of each animal
	 * @param y, <code>y</code> is y-coordinate of each animal
	 */
	public Animal(char name, int x, int y){
		this.name=name;
		this.x=x;
		this.y=y;
	}
	
	
	/**
	 * Function returns name of animal
	 * @return <code>name</code> of animal
	 */
	public char getName(){
		return this.name;
	}
	
	/**
	 * function return x coordinate of animal
	 * @return <code>x</code> x-coordinate of animal
	 */
	public int getX(){
		return this.x;
	}
	
	/**
	 * function return y coordinate of animal
	 * @return <code>y</code> y-coordinate of animal
	 */
	public int getY(){
		return this.y;
	}
	
	/**
	 * Function changes location of Animal
	 * @param x, <code>x</code> new x-coordinate
	 * @param y, <code>y</code> new y-coordinate
	 */
	public void move(int x, int y){
		this.x=x;
		this.y=y;
	}
	
	/**
	 * Function attack for each Animal
	 * @param a, <code>a</code> is the Animal being attacked
	 * @return Animal winner
	 */
	public Animal attack(Animal a){
		System.out.println( this.getClass().getSimpleName() + " from " + this.x +", " + this.y 
				+" attacks " + a.getClass().getSimpleName() + " at " +  a.getX() +", "+ a.getY() + " and loses");
			System.out.println(this.getClass().getSimpleName() + " dies at " + this.x + ", " + this.y);
			return a;
	}
	
	/**
	 * Function generates possible new location of animal
	 * @return new location
	 */
	public int[] getALoc(){
		boolean bInside=false;
		char[] cDir={'r','l','u','d'};
		Random rand = new Random();
		int[] iNewXY=new int[2];
		int iDistance=1;		//distance of one
		while(bInside==false){
			int iChar=rand.nextInt(4);   		//get possible direction
			if (cDir[iChar]=='r' && this.x-iDistance>=0){
				bInside=true;
				iNewXY[0]=this.x-iDistance;
				iNewXY[1]=this.y;
			}else if (cDir[iChar]=='l' && this.x+iDistance<=14){
				bInside=true;
				iNewXY[0]=this.x+iDistance;
				iNewXY[1]=this.y;
			}else if (cDir[iChar]=='u' && this.y-iDistance>=0){
				bInside=true;
				iNewXY[0]=this.x;
				iNewXY[1]=this.y-iDistance;
			}else if (cDir[iChar]=='d' && this.y+iDistance<=14){
				bInside=true;
				iNewXY[0]=this.x;
				iNewXY[1]=this.y+iDistance;
			}else{
				bInside=false;
			}
		}
			return iNewXY;
		
	}
	
	
	/**
	 * method returns a list of all possible location of an animal
	 * @return ArrayList of possible coordinates
	 */
	public ArrayList<Coordinates> getAllLocs(){
		ArrayList<Coordinates> allLoc=new ArrayList<Coordinates>();
		Integer[] loc=new Integer[2];
				
		if (this.x-1>=0){		
			loc[0]=this.x-1;
			loc[1]=this.y;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.x+1<=14){			
			loc[0]=this.x+1;
			loc[1]=this.y;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.y-1>=0){			
			loc[0]=this.x;
			loc[1]=this.y-1;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.y+1<=14){			
			loc[0]=this.x;
			loc[1]=this.y+1;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
			
		
		return allLoc;
	}

}
