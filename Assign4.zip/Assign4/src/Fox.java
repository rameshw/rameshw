import javax.swing.ImageIcon;

/**
 * Subclass for Animals of Fox type
 * @author rameshweerakoon
 *
 */
public class Fox extends Canine{
	/**
	 * Name of Fox
	 */
	public  static  char name='f';
	/**
	 * Location of Icon
	 */
	public  static String icon;
	
	/**
	 * Constructor for Fox
	 * @param x, <code>x</code> is x-coordinate of each Fox
	 * @param y, <code>y</code> is y-coordinate of each Fox
	 */
	public Fox(int x, int y) {
		super('f',x,y);
		System.out.println(this.getClass().getSimpleName()+" initialized at " + x +", "+y);
	}
	
	/**
	 * change location of icon
	 * @param a, new location of string
	 */
	public static void changeIcon(String a){
		Fox.icon = a;
	}
	
	/**
	 * get location of Icon
	 * @return string, location of icon
	 */
	public static String getIcon(){
		return Fox.icon ;
	}
	
	/**
	 * Function attack for each Fox
	 * @param a, <code>a</code> is the Animal being attacked
	 * @return Animal winner
	 */
	public Animal attack(Animal a){
		if ((a instanceof Cat)){		//if animal being attacked in a Cat
			System.out.println( this.getClass().getSimpleName() + " from " + super.x +", " + super.y 
					+" attacks " + a.getClass().getSimpleName() + " at " +  a.getX() +", "+ a.getY() + " and wins");
			System.out.println(a.getClass().getSimpleName()+ " dies at " + a.getX() + ", " + a.getY());
			return this;
		}else{			//else refer to super class
			Animal winner=super.attack(a);
			return winner;
		}
	}
}
