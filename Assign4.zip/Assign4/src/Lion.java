import javax.swing.ImageIcon;



/**
 * Subclass for Animals of Lion type
 * @author rameshweerakoon
 *
 */
public class Lion extends Feline{
	/**
	 * Name of Lion
	 */
	public  static  char name='l';
	/**
	 * Location of Icon
	 */
	public  static String icon;
	
	/**
	 * Constructor for Lion
	 * @param x, <code>x</code> is x-coordinate of each Lion
	 * @param y, <code>y</code> is y-coordinate of each Lion
	 */
	public Lion(int x, int y) {
		super('l',x,y);
		System.out.println(this.getClass().getSimpleName()+" initialized at " + x +", "+y);
	}
	
	/**
	 * change location of icon
	 * @param a, new location of string
	 */
	public static void changeIcon(String a){
		Lion.icon = a;
	}
	
	/**
	 * get location of Icon
	 * @return string, location of icon
	 */
	public static String getIcon(){
		return Lion.icon ;
	}
	
	/**
	 * Function attack for each Lion
	 * @param a, <code>a</code> is the Animal being attacked
	 * @return Animal winner
	 */
	public Animal attack(Animal a){
		if ((a instanceof Hippo)){				//if animal being attacked is a Hippo
			System.out.println( this.getClass().getSimpleName() + " from " + super.getX() +", " + super.getY() 
					+" attacks " + a.getClass().getSimpleName() + " at " +  a.getX() +", "+ a.getY() + " and wins");
			System.out.println(a.getClass().getSimpleName() + " dies at " + a.getX() + ", " + a.getY());
			return this;
		}else{					//else refer to super class
			Animal winner=super.attack(a);
			return winner;
		}
	}

}
