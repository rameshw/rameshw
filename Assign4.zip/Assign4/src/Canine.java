
import java.util.ArrayList;
import java.util.Random;

/**
 * Subclass for Animals of Canine type
 * @author rameshweerakoon
 *
 */
public abstract class Canine extends Animal{
	
	/**
	 * Constructor for Canine
	 * @param name, <code>name</code> is name of each Canine
	 * @param x, <code>x</code> is x-coordinate of each Canine
	 * @param y, <code>y</code> is y-coordinate of each Canine
	 */
	public Canine(char name, int x, int y) {
		super(name, x, y);
	}
	
	/**
	 * Function generates possible new location of animal
	 * @return new location of Animal
	 */
	public int[] getALoc(){
		boolean bInside=false;
		char[] cDir={'r','l','u','d'};
		Random rand = new Random();
		int[] iNewXY=new int[2];
		int iDistance=rand.nextInt(2)+1;	//select possible distance
		while(bInside==false){
			int iChar=rand.nextInt(4);		//select possible direction
			
			//check if its inside Forest
			if (cDir[iChar]=='r' && super.x-iDistance>=0){
				bInside=true;
				iNewXY[0]=super.x-iDistance;
				iNewXY[1]=super.y;
			}else if (cDir[iChar]=='l' && super.x+iDistance<=14){
				bInside=true;
				iNewXY[0]=super.x+iDistance;
				iNewXY[1]=super.y;
			}else if (cDir[iChar]=='u' && super.y-iDistance>=0){
				bInside=true;
				iNewXY[0]=super.x;
				iNewXY[1]=super.y-iDistance;
			}else if (cDir[iChar]=='d' && super.y+iDistance<=14){
				bInside=true;
				iNewXY[0]=super.x;
				iNewXY[1]=super.y+iDistance;
			}else{
				bInside=false;
			}
		}
			return iNewXY;
	}
	
	/**
	 * Function attack for each Canine
	 * @param a, <code>a</code> is the Animal being attacked
	 * @return Animal winner
	 */
	public Animal attack(Animal a){
		Random rand = new Random();
		int iDies=rand.nextInt(2);
		if ((a instanceof Feline)){		//if animal being attacked is Feline  
			if (iDies==0){				//Feline dies
				System.out.println( this.getClass().getSimpleName() + " from " + super.x +", " + super.y 
						+" attacks " + a.getClass().getSimpleName() + " at " +  a.getX() +", "+ a.getY() + " and wins");
				System.out.println(a.getClass().getSimpleName() + " dies at " + a.getX() + ", " + a.getY());
				return this;
			}else{						//Canine dies
				System.out.println( this.getClass().getSimpleName() + " from " + super.x +", " + super.y 
						+" attacks " + a.getClass().getSimpleName() + " at " +  a.getX() +", "+ a.getY() + " and loses");
				System.out.println(this.getClass().getSimpleName() + " dies at " + super.x + ", " + super.y);
				return a;
			}
		}else{		//if not Feline, refer to super class
			Animal winner=super.attack(a);
			return winner;
		}
	}
	
	/**
	 * method returns a list of all possible location of an animal
	 * @return ArrayList of possible coordinates
	 */
	public ArrayList<Coordinates> getAllLocs(){
		ArrayList<Coordinates> allLoc=new ArrayList<Coordinates>();
		Integer[] loc=new Integer[2];
				
		if (this.x-1>=0){		
			loc[0]=this.x-1;
			loc[1]=this.y;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.x+1<=14){			
			loc[0]=this.x+1;
			loc[1]=this.y;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.y-1>=0){			
			loc[0]=this.x;
			loc[1]=this.y-1;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.y+1<=14){			
			loc[0]=this.x;
			loc[1]=this.y+1;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.x-2>=0){		
			loc[0]=this.x-2;
			loc[1]=this.y;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.x+2<=14){			
			loc[0]=this.x+2;
			loc[1]=this.y;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.y-2>=0){			
			loc[0]=this.x;
			loc[1]=this.y-2;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
		if (this.y+2<=14){			
			loc[0]=this.x;
			loc[1]=this.y+2;
			allLoc.add(new Coordinates(loc[0],loc[1]));
		}
			
		
		return allLoc;
	}
}
